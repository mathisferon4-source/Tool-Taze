# OSINT FINDER — Dark Edition

## Lancer l'application
1. Décompresse `osint_finder_dark.zip`.
2. Ouvre le dossier `osint_finder_dark`.
3. Double-clique sur `index.html` pour ouvrir l'application dans ton navigateur.

Aucun serveur ni installation n'est nécessaire pour cette première version.

## Fonctions
- Recherche de pseudos via des liens vers des moteurs de recherche publics.
- Analyse locale des caractéristiques d'une image (format, taille, dimensions).
- Recherche de pages publiques par nom ou sujet.
- Accès au site officiel Have I Been Pwned pour vérifier une adresse qui t'appartient.
- Historique conservé dans le stockage local du navigateur.

## Limites et sécurité
- Les recherches web sont ouvertes dans un nouvel onglet ; l'application ne scrape pas les sites.
- L'image choisie reste dans le navigateur.
- Aucun numéro de téléphone, adresse privée, mot de passe, contenu volé ou photo intime divulguée n'est collecté.
- Les résultats de recherche ne prouvent pas l'identité d'une personne.
- Pour une utilisation réelle, respecte les lois et les conditions des sites consultés.
