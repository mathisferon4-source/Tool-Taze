import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { MapContainer, TileLayer, Marker } from 'react-leaflet';
import L from 'leaflet';

function PhantomDashboard() {
    const [target, setTarget] = useState('');
    const [results, setResults] = useState(null);
    const [loading, setLoading] = useState(false);
    const [images, setImages] = useState([]);

    const handleSearch = async () => {
        setLoading(true);
        try {
            // Appel à l'API FastAPI
            const response = await axios.post('http://localhost:8000/trace', { target });
            setResults(response.data);
            // Récupération des images (si module Facerecog activé)
            const imgResponse = await axios.get('http://localhost:8000/facerecog/images', { params: { target } });
            setImages(imgResponse.data);
        } catch (error) {
            console.error("Erreur :", error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="dashboard">
            <h1>PHANTOM OSINT TOOL</h1>
            <div className="search-box">
                <input
                    type="text"
                    placeholder="Pseudo, email, numéro de téléphone..."
                    value={target}
                    onChange={(e) => setTarget(e.target.value)}
                />
                <button onClick={handleSearch} disabled={loading}>
                    {loading ? "Analyse en cours..." : "Lancer la recherche"}
                </button>
            </div>

            {results && (
                <div className="results-container">
                    <h2>Résultats pour : {target}</h2>
                    <div className="tab">
                        <button className="active">Profil Numérique</button>
                        <button>Réseaux Sociaux</button>
                        <button>Localisation</button>
                        <button>Dark Web</button>
                    </div>

                    <div className="profile-section">
                        <h3>Profil Numérique</h3>
                        <pre>{JSON.stringify(results, null, 2)}</pre>
                    </div>

                    {images.length > 0 && (
                        <div className="images-section">
                            <h3>Images Correspondantes</h3>
                            <div className="image-grid">
                                {images.map((img, index) => (
                                    <div key={index} className="image-card">
                                        <img src={img.url} alt={`Correspondance ${index}`} />
                                        <p>Similarité : {img.similarity.toFixed(2)}</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {results.ip_history.length > 0 && (
                        <div className="map-section">
                            <h3>Historique de Localisation</h3>
                            <MapContainer center={[51.505, -0.09]} zoom={2} style={{ height: '400px' }}>
                                <TileLayer
                                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                                />
                                {results.ip_history.map((ip, index) => (
                                    ip.location && (
                                        <Marker
                                            key={index}
                                            position={[ip.location["lat"], ip.location["lon"]]}
                                            eventHandlers={{
                                                click: () => alert(`IP : ${ip.ip}\nLocalisation : ${ip.location["city"]}, ${ip.location["region"]}`)
                                            }}
                                        />
                                    )
                                ))}
                            </MapContainer>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}

export default PhantomDashboard;