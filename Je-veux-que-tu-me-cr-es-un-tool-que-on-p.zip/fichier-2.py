import requests
from bs4 import BeautifulSoup
from googlesearch import search
import re
import json
from datetime import datetime
import pytz
import whois
import ipinfo
from theharvester import theharvester

class PhantomTracer:
    def __init__(self, target):
        self.target = target
        self.results = {
            "social_media": {},
            "emails": [],
            "phones": [],
            "domains": [],
            "ip_history": [],
            "news_mentions": [],
            "dark_web": [],
            "metadata": {}
        }
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }

    def google_dorking(self, query):
        """Recherche avancée via Google Dorks."""
        dorks = [
            f'site:twitter.com "{self.target}"',
            f'site:linkedin.com/in "{self.target}"',
            f'site:facebook.com "{self.target}"',
            f'site:instagram.com "{self.target}"',
            f'filetype:pdf "{self.target}"',
            f'intext:"{self.target}" -site:twitter.com -site:linkedin.com',
            f'cache:"{self.target}"'  # Wayback Machine
        ]
        for dork in dorks:
            try:
                for url in search(dork, num=10, pause=2):
                    self.results["news_mentions"].append({"source": url, "dork": dork})
            except Exception as e:
                print(f"[!] Erreur Google Dorking : {e}")

    def scrape_social_media(self):
        """Scraping basique des profils sociaux (à améliorer avec Selenium)."""
        social_platforms = {
            "twitter": f"https://twitter.com/search?q={self.target}",
            "linkedin": f"https://www.linkedin.com/search/results/all/?keywords={self.target}",
            "facebook": f"https://www.facebook.com/public/{self.target}"
        }
        for platform, url in social_platforms.items():
            try:
                response = requests.get(url, headers=self.headers)
                soup = BeautifulSoup(response.text, 'html.parser')
                if "not found" not in response.text.lower():
                    self.results["social_media"][platform] = {
                        "url": url,
                        "snippet": soup.find("meta", {"property": "og:description"})["content"] if soup.find("meta", {"property": "og:description"}) else "No description"
                    }
            except Exception as e:
                print(f"[!] Erreur {platform} : {e}")

    def harvest_emails(self):
        """Utilisation de TheHarvester pour trouver des emails."""
        try:
            th = theharvester.TheHarvester(self.target, self.target, 10)
            emails = th.start()["emails"]
            for email in emails:
                if email not in self.results["emails"]:
                    self.results["emails"].append(email)
        except Exception as e:
            print(f"[!] Erreur TheHarvester : {e}")

    def analyze_ip(self, ip):
        """Analyse d'une IP (via IPinfo.io)."""
        try:
            handler = ipinfo.getHandler(token="VOTRE_CLE_IPINFO")  # Remplacez par une clé valide
            details = handler.getDetails(ip)
            self.results["ip_history"].append({
                "ip": ip,
                "location": details.location,
                "org": details.org,
                "asn": details.asn,
                "hostname": details.hostname,
                "timestamp": datetime.now(pytz.utc).isoformat()
            })
        except Exception as e:
            print(f"[!] Erreur IP Analysis : {e}")

    def run(self):
        """Lancement de toutes les analyses."""
        print(f"[*] Début de l'analyse pour : {self.target}")
        self.google_dorking(self.target)
        self.scrape_social_media()
        self.harvest_emails()
        print("[+] Analyse terminée. Résultats :")
        print(json.dumps(self.results, indent=4))

# Exécution
if __name__ == "__main__":
    tracer = PhantomTracer("Jean Dupont")
    tracer.run()