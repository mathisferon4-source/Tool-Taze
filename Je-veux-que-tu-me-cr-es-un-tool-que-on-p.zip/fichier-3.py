import face_recognition
import requests
from io import BytesIO
from PIL import Image
import os

class FaceRecognizer:
    def __init__(self, target_image_path):
        self.target_image = face_recognition.load_image_file(target_image_path)
        self.target_encoding = face_recognition.face_encodings(self.target_image)[0]
        self.results = []

    def search_on_google_images(self, query):
        """Recherche d'images similaires sur Google Images."""
        try:
            for url in search(f"{query} face", num=50, pause=2):
                if "google.com" in url:
                    response = requests.get(url)
                    img = Image.open(BytesIO(response.content))
                    img_encoding = face_recognition.face_encodings(img)
                    if img_encoding:
                        matches = face_recognition.compare_faces([self.target_encoding], img_encoding[0], tolerance=0.5)
                        if matches[0]:
                            self.results.append({
                                "url": url,
                                "similarity": face_recognition.face_distance([self.target_encoding], img_encoding[0])[0],
                                "metadata": self._extract_metadata(img)
                            })
        except Exception as e:
            print(f"[!] Erreur Google Images : {e}")

    def _extract_metadata(self, img):
        """Extraction des métadonnées EXIF."""
        try:
            exif_data = img._getexif()
            return {
                "gps": exif_data.get(34853),  # GPSInfo
                "camera": exif_data.get(272),  # Make
                "model": exif_data.get(273),   # Model
                "datetime": exif_data.get(36867)  # DateTime
            }
        except:
            return {}

    def run(self):
        """Lancement de la reconnaissance."""
        print(f"[*] Recherche de visages similaires pour l'image cible...")
        self.search_on_google_images("person")
        print(f"[+] {len(self.results)} correspondances trouvées.")
        for res in self.results:
            print(f"URL : {res['url']} | Similarité : {res['similarity']:.2f}")

# Exécution
if __name__ == "__main__":
    recognizer = FaceRecognizer("target_face.jpg")
    recognizer.run()